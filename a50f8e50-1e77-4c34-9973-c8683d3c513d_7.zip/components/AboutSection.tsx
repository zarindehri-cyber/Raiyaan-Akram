
'use client';

export default function AboutSection() {
  return (
    <section className="bg-gray-900 py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-block bg-cyan-400/10 border border-cyan-400/20 rounded-full px-4 py-2">
              <span className="text-cyan-400 text-sm font-medium">About Me</span>
            </div>
            
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Passionate about{' '}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Innovation
              </span>
            </h2>
            
            <p className="text-lg text-gray-300 leading-relaxed">
              I'm Raiyaan Akram, a dedicated full-stack developer with a passion for creating cutting-edge digital solutions. 
              With expertise spanning modern web frameworks, cloud architecture, and AI integration, I help businesses 
              transform their ideas into powerful, scalable applications.
            </p>
            
            <p className="text-lg text-gray-300 leading-relaxed">
              My approach combines technical excellence with creative problem-solving, ensuring every project delivers 
              exceptional user experiences and robust performance. I stay at the forefront of technology trends to 
              provide innovative solutions that drive business growth.
            </p>
            
            <div className="grid grid-cols-2 gap-6 pt-6">
              <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
                <div className="text-3xl font-bold text-cyan-400 mb-2">50+</div>
                <div className="text-gray-300">Projects Completed</div>
              </div>
              <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
                <div className="text-3xl font-bold text-cyan-400 mb-2">5+</div>
                <div className="text-gray-300">Years Experience</div>
              </div>
              <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
                <div className="text-3xl font-bold text-cyan-400 mb-2">30+</div>
                <div className="text-gray-300">Happy Clients</div>
              </div>
              <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
                <div className="text-3xl font-bold text-cyan-400 mb-2">24/7</div>
                <div className="text-gray-300">Support Available</div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl blur-2xl opacity-20"></div>
              <div className="relative bg-gradient-to-br from-gray-800 to-gray-900 p-2 rounded-2xl">
                <img 
                  src="https://static.readdy.ai/image/3fbf25e89c37fa8d8d1d71ded54d58e6/5675dfab388dcb10fe10b6010f453757.jfif"
                  alt="Raiyaan Akram - Professional Developer"
                  className="w-80 h-96 lg:w-96 lg:h-[28rem] object-cover object-top rounded-xl"
                />
              </div>
              <div className="absolute -top-4 -left-4 bg-gradient-to-r from-cyan-400 to-blue-500 text-black px-4 py-2 rounded-lg font-semibold text-sm">
                🚀 Tech Expert
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
