
'use client';

import Link from 'next/link';

export default function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-r from-gray-900 via-black to-gray-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10"></div>
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Let's Build Something <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Amazing</span> Together
          </h2>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Ready to transform your ideas into reality? I'm available for freelance projects, 
            collaborations, and full-time opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/contact" className="bg-gradient-to-r from-cyan-400 to-blue-500 text-black px-8 py-4 rounded-lg font-semibold text-lg hover:shadow-lg hover:shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap">
              Start a Project
            </Link>
            <Link href="/projects" className="border-2 border-cyan-400 text-cyan-400 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-cyan-400 hover:text-black transition-all cursor-pointer whitespace-nowrap">
              View Portfolio
            </Link>
          </div>
          
          <div className="flex justify-center items-center space-x-8 text-gray-500">
            <div className="flex items-center space-x-2">
              <i className="ri-time-line text-cyan-400"></i>
              <span>Quick Response</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-shield-check-line text-cyan-400"></i>
              <span>Quality Guaranteed</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-global-line text-cyan-400"></i>
              <span>Remote Ready</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute top-10 left-10 w-20 h-20 border border-cyan-400/20 rounded-full"></div>
      <div className="absolute bottom-10 right-10 w-32 h-32 border border-blue-500/20 rounded-full"></div>
      <div className="absolute top-1/2 left-1/4 w-2 h-2 bg-cyan-400 rounded-full"></div>
      <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-blue-500 rounded-full"></div>
    </section>
  );
}
