
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-black text-white border-t border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
              Raiyaan Akram
            </div>
            <p className="text-gray-400 mb-4">
              Full-stack developer passionate about creating innovative digital solutions with cutting-edge technologies.
            </p>
            <div className="flex space-x-4">
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-github-fill text-xl"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-linkedin-fill text-xl"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-twitter-fill text-xl"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-dribbble-fill text-xl"></i>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-cyan-400">Navigation</h3>
            <div className="space-y-2">
              <Link href="/about" className="text-gray-400 hover:text-white cursor-pointer block transition-colors">
                About Me
              </Link>
              <Link href="/skills" className="text-gray-400 hover:text-white cursor-pointer block transition-colors">
                Skills & Tech
              </Link>
              <Link href="/projects" className="text-gray-400 hover:text-white cursor-pointer block transition-colors">
                Portfolio
              </Link>
              <Link href="/experience" className="text-gray-400 hover:text-white cursor-pointer block transition-colors">
                Experience
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-cyan-400">Services</h3>
            <div className="space-y-2">
              <p className="text-gray-400">Web Development</p>
              <p className="text-gray-400">Mobile Apps</p>
              <p className="text-gray-400">Cloud Solutions</p>
              <p className="text-gray-400">AI Integration</p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-cyan-400">Get In Touch</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-mail-line text-sm text-cyan-400"></i>
                </div>
                <p className="text-gray-400">raiyaan@example.com</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-map-pin-line text-sm text-cyan-400"></i>
                </div>
                <p className="text-gray-400">Available Worldwide</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-time-line text-sm text-cyan-400"></i>
                </div>
                <p className="text-gray-400">Response within 24hrs</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 mb-4 md:mb-0">
            2024 Raiyaan Akram. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm">
            <Link href="/privacy" className="text-gray-400 hover:text-cyan-400 cursor-pointer transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-gray-400 hover:text-cyan-400 cursor-pointer transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-6 pt-6">
          <div className="text-center">
            <h4 className="text-sm font-semibold text-cyan-400 mb-3">Important Disclaimers - IT IS JOKE</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-gray-500">
              <div>
                <p className="font-medium text-gray-400 mb-1">Professional Services</p>
                <p>All services are provided on a best-effort basis. Results may vary based on project requirements and complexity.</p>
              </div>
              <div>
                <p className="font-medium text-gray-400 mb-1">Technical Information</p>
                <p>Technical specifications and capabilities are subject to change. Always consult for current information before projects.</p>
              </div>
              <div>
                <p className="font-medium text-gray-400 mb-1">Third-Party Services</p>
                <p>Integration with third-party services depends on their availability and terms. We are not responsible for external service disruptions.</p>
              </div>
              <div>
                <p className="font-medium text-gray-400 mb-1">Liability Limitation</p>
                <p>Our liability is limited to the project scope agreed upon. Users are responsible for data backup and security measures.</p>
              </div>
            </div>
            <div className="mt-4 text-xs text-gray-600">
              <p>This website is for informational purposes. All trademarks and registered trademarks are property of their respective owners. Contact us for specific terms and conditions regarding professional services. - IT IS JOKE</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
