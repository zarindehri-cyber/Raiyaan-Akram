
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-black/90 backdrop-blur-md shadow-lg border-b border-gray-800 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="text-2xl font-bold text-white" style={{ fontFamily: 'Pacifico, serif' }}>
              Raiyaan Akram
            </div>
            <div className="text-cyan-400 text-sm hidden sm:block">{'{ Developer }'}</div>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-300 hover:text-cyan-400 font-medium whitespace-nowrap cursor-pointer transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-gray-300 hover:text-cyan-400 font-medium whitespace-nowrap cursor-pointer transition-colors">
              About
            </Link>
            <Link href="/skills" className="text-gray-300 hover:text-cyan-400 font-medium whitespace-nowrap cursor-pointer transition-colors">
              Skills
            </Link>
            <Link href="/projects" className="text-gray-300 hover:text-cyan-400 font-medium whitespace-nowrap cursor-pointer transition-colors">
              Projects
            </Link>
            <Link href="/experience" className="text-gray-300 hover:text-cyan-400 font-medium whitespace-nowrap cursor-pointer transition-colors">
              Experience
            </Link>
            <Link href="/contact" className="text-gray-300 hover:text-cyan-400 font-medium whitespace-nowrap cursor-pointer transition-colors">
              Contact
            </Link>
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden w-6 h-6 flex items-center justify-center cursor-pointer text-white"
          >
            <i className="ri-menu-line text-xl"></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-800">
            <div className="flex flex-col space-y-3">
              <Link href="/" className="text-gray-300 hover:text-cyan-400 font-medium cursor-pointer transition-colors">
                Home
              </Link>
              <Link href="/about" className="text-gray-300 hover:text-cyan-400 font-medium cursor-pointer transition-colors">
                About
              </Link>
              <Link href="/skills" className="text-gray-300 hover:text-cyan-400 font-medium cursor-pointer transition-colors">
                Skills
              </Link>
              <Link href="/projects" className="text-gray-300 hover:text-cyan-400 font-medium cursor-pointer transition-colors">
                Projects
              </Link>
              <Link href="/experience" className="text-gray-300 hover:text-cyan-400 font-medium cursor-pointer transition-colors">
                Experience
              </Link>
              <Link href="/contact" className="text-gray-300 hover:text-cyan-400 font-medium cursor-pointer transition-colors">
                Contact
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
