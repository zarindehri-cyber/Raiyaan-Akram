
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-br from-black via-gray-900 to-black min-h-screen flex items-center">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center space-x-2 bg-cyan-400/10 border border-cyan-400/20 rounded-full px-4 py-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-sm font-medium">Available for projects</span>
            </div>
            
            <h1 className="text-5xl lg:text-7xl font-bold text-white leading-tight">
              Hi, I'm{' '}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Raiyaan Akram
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 leading-relaxed max-w-2xl">
              Full-stack developer specializing in modern web technologies, AI integration, and scalable cloud solutions. 
              I transform innovative ideas into powerful digital experiences.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact" className="bg-gradient-to-r from-cyan-400 to-blue-500 text-black px-8 py-4 rounded-lg font-semibold hover:from-cyan-300 hover:to-blue-400 transition-all duration-300 text-center whitespace-nowrap cursor-pointer">
                Start a Project
              </Link>
              <Link href="/projects" className="border border-gray-600 text-white px-8 py-4 rounded-lg font-semibold hover:border-cyan-400 hover:text-cyan-400 transition-all duration-300 text-center whitespace-nowrap cursor-pointer">
                View My Work
              </Link>
            </div>
            
            <div className="flex items-center space-x-6 pt-4">
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-github-fill text-xl"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-linkedin-fill text-xl"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-gray-800 hover:bg-cyan-400 hover:text-black rounded-full cursor-pointer transition-all">
                <i className="ri-twitter-fill text-xl"></i>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl blur-2xl opacity-30 animate-pulse"></div>
              <div className="relative bg-gradient-to-br from-gray-800 to-gray-900 p-2 rounded-2xl">
                <img 
                  src="https://static.readdy.ai/image/3fbf25e89c37fa8d8d1d71ded54d58e6/5675dfab388dcb10fe10b6010f453757.jfif"
                  alt="Raiyaan Akram - Full Stack Developer"
                  className="w-80 h-80 lg:w-96 lg:h-96 object-cover object-top rounded-xl"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-cyan-400 to-blue-500 text-black px-4 py-2 rounded-lg font-semibold text-sm">
                💻 Developer
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
