
'use client';

import Link from 'next/link';

export default function SkillsSection() {
  const skillCategories = [
    {
      title: "Frontend Development",
      description: "Creating responsive and interactive user interfaces with modern frameworks.",
      image: "Modern frontend development workspace with React code on screen, sleek UI design mockups, colorful component libraries, responsive web design layouts, contemporary developer setup with multiple monitors",
      technologies: ["React", "Next.js", "TypeScript", "Tailwind CSS"]
    },
    {
      title: "Backend Development", 
      description: "Building robust server-side applications and APIs with scalable architecture.",
      image: "Backend development environment with server architecture diagrams, API documentation, database schemas, cloud infrastructure, microservices visualization, dark theme code editor with server-side code",
      technologies: ["Node.js", "Python", "PostgreSQL", "MongoDB"]
    },
    {
      title: "Cloud & DevOps",
      description: "Deploying and managing applications with cloud infrastructure and automation.",
      image: "Cloud computing dashboard with AWS services, Docker containers, Kubernetes clusters, CI/CD pipelines, monitoring graphs, DevOps automation tools, modern infrastructure management interface",
      technologies: ["AWS", "Docker", "Kubernetes", "CI/CD"]
    },
    {
      title: "AI & Machine Learning",
      description: "Implementing intelligent solutions using machine learning and AI technologies.",
      image: "Artificial intelligence development environment with neural network visualizations, machine learning models, data analysis charts, AI algorithms, futuristic tech interface with data flows and predictions",
      technologies: ["TensorFlow", "PyTorch", "OpenAI API", "Data Science"]
    }
  ];

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Technical Expertise</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Specialized in cutting-edge technologies to deliver innovative solutions across the full development stack.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((skill, index) => (
            <div key={index} className="bg-gray-800 rounded-xl shadow-2xl overflow-hidden hover:shadow-cyan-500/10 transition-all hover:transform hover:scale-105">
              <div 
                className="h-64 bg-cover bg-center relative"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=$%7Bskill.image%7D&width=600&height=400&seq=skill${index + 1}&orientation=landscape')`
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-white mb-4">{skill.title}</h3>
                <p className="text-gray-400 mb-6">{skill.description}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {skill.technologies.map((tech, techIndex) => (
                    <span key={techIndex} className="bg-cyan-400/10 text-cyan-400 px-3 py-1 rounded-full text-sm font-medium border border-cyan-400/20">
                      {tech}
                    </span>
                  ))}
                </div>
                <Link href="/skills" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer transition-colors">
                  Learn More 
                  <div className="w-4 h-4 flex items-center justify-center ml-2">
                    <i className="ri-arrow-right-line"></i>
                  </div>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
